"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

type SustainabilityData = {
  carbonFootprint: number
  waterFootprint: number
  energyConsumption: number
  wasteRecycled: number
  sustainableTravel: number
  ecoFriendlyPurchases: number
  solarEnergyGenerated: number
  sustainableDietScore: number
  waterConserved: number
  sustainabilityScore: number
}

type SustainabilityContextType = {
  data: SustainabilityData
  updateData: (key: keyof SustainabilityData, value: number) => void
}

const SustainabilityContext = createContext<SustainabilityContextType | undefined>(undefined)

export const useSustainability = () => {
  const context = useContext(SustainabilityContext)
  if (!context) {
    throw new Error("useSustainability must be used within a SustainabilityProvider")
  }
  return context
}

export const SustainabilityProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [data, setData] = useState<SustainabilityData>({
    carbonFootprint: 0,
    waterFootprint: 0,
    energyConsumption: 0,
    wasteRecycled: 0,
    sustainableTravel: 0,
    ecoFriendlyPurchases: 0,
    solarEnergyGenerated: 0,
    sustainableDietScore: 0,
    waterConserved: 0,
    sustainabilityScore: 0,
  })

  useEffect(() => {
    // Load data from localStorage on initial render
    const savedData = localStorage.getItem("sustainabilityData")
    if (savedData) {
      setData(JSON.parse(savedData))
    }
  }, [])

  useEffect(() => {
    // Save data to localStorage whenever it changes
    localStorage.setItem("sustainabilityData", JSON.stringify(data))
  }, [data])

  const updateData = (key: keyof SustainabilityData, value: number) => {
    setData((prevData) => {
      const newData = { ...prevData, [key]: value }
      // Recalculate sustainability score
      newData.sustainabilityScore = Object.values(newData).reduce((a, b) => a + b, 0) / Object.keys(newData).length
      return newData
    })
  }

  return <SustainabilityContext.Provider value={{ data, updateData }}>{children}</SustainabilityContext.Provider>
}

