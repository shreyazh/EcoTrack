"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useSustainability, type SustainabilityData } from "@/contexts/SustainabilityContext"

interface CalculatorProps {
  title: string
  description: string
  fields: {
    name: string
    label: string
    type: "number" | "select"
    options?: string[]
  }[]
  onCalculate: (values: Record<string, number | string>) => number
  resultUnit: string
  updateKey: keyof SustainabilityData
}

export function Calculator({ title, description, fields, onCalculate, resultUnit, updateKey }: CalculatorProps) {
  const [values, setValues] = useState<Record<string, number | string>>({})
  const [result, setResult] = useState<number | null>(null)
  const { updateData } = useSustainability()

  const handleInputChange = (name: string, value: number | string) => {
    setValues((prev) => ({ ...prev, [name]: value }))
  }

  const handleCalculate = () => {
    const calculatedResult = onCalculate(values)
    setResult(calculatedResult)
    updateData(updateKey, calculatedResult)
  }

  return (
    <Card className="w-full max-w-2xl mx-auto bg-green-900 border-green-700">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {fields.map((field) => (
          <div key={field.name} className="space-y-2">
            <Label htmlFor={field.name}>{field.label}</Label>
            {field.type === "number" ? (
              <Input
                id={field.name}
                type="number"
                value={values[field.name] || ""}
                onChange={(e) => handleInputChange(field.name, Number.parseFloat(e.target.value))}
                className="bg-green-800 border-green-700 text-green-100"
              />
            ) : (
              <Select onValueChange={(value) => handleInputChange(field.name, value)}>
                <SelectTrigger className="bg-green-800 border-green-700 text-green-100">
                  <SelectValue placeholder="Select..." />
                </SelectTrigger>
                <SelectContent>
                  {field.options?.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
        ))}
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button onClick={handleCalculate}>Calculate</Button>
        {result !== null && (
          <div className="text-xl font-bold">
            Result: {result.toFixed(2)} {resultUnit}
          </div>
        )}
      </CardFooter>
    </Card>
  )
}

