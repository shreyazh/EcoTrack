import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Home,
  BarChart2,
  Droplet,
  Zap,
  Recycle,
  Car,
  ShoppingBag,
  Sun,
  Apple,
  Leaf,
  Trophy,
  FileText,
  HelpCircle,
} from "lucide-react"

const routes = [
  { name: "Dashboard", icon: Home, path: "/" },
  { name: "Carbon Footprint", icon: BarChart2, path: "/carbon-footprint" },
  { name: "Water Footprint", icon: Droplet, path: "/water-footprint" },
  { name: "Energy Consumption", icon: Zap, path: "/energy-consumption" },
  { name: "Waste & Recycling", icon: Recycle, path: "/waste-recycling" },
  { name: "Sustainable Travel", icon: Car, path: "/sustainable-travel" },
  { name: "Eco-Friendly Shopping", icon: ShoppingBag, path: "/eco-shopping" },
  { name: "Home Solar Potential", icon: Sun, path: "/solar-potential" },
  { name: "Sustainable Diet", icon: Apple, path: "/sustainable-diet" },
  { name: "Green Energy & Water", icon: Leaf, path: "/green-energy-water" },
  { name: "Sustainability Game", icon: Trophy, path: "/sustainability-game" },
  { name: "Guidelines", icon: FileText, path: "/guidelines" },
  { name: "Help", icon: HelpCircle, path: "/help" },
]

export function Sidebar() {
  return (
    <div className="w-64 bg-green-900 text-green-100 flex flex-col border-r border-green-700">
      <div className="p-4">
        <h1 className="text-2xl font-bold tracking-tight">EcoTrack</h1>
      </div>
      <ScrollArea className="flex-1">
        <nav className="space-y-2 p-2">
          {routes.map((route) => (
            <Link key={route.path} href={route.path}>
              <Button variant="ghost" className="w-full justify-start">
                <route.icon className="mr-2 h-4 w-4" />
                {route.name}
              </Button>
            </Link>
          ))}
        </nav>
      </ScrollArea>
    </div>
  )
}

