import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function HelpPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold tracking-tight">Help & FAQ</h1>

      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="item-1">
          <AccordionTrigger>How do I use the calculators?</AccordionTrigger>
          <AccordionContent>
            Each calculator page has input fields for relevant data. Fill in the required information and click the
            "Calculate" button to see your results. The results will automatically update on your dashboard.
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="item-2">
          <AccordionTrigger>How is my sustainability score calculated?</AccordionTrigger>
          <AccordionContent>
            Your sustainability score is an aggregate of all your individual scores from different categories such as
            carbon footprint, water usage, energy consumption, etc. It's updated in real-time as you use the various
            calculators and complete challenges in the Sustainability Game.
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="item-3">
          <AccordionTrigger>What do the different colors on the dashboard mean?</AccordionTrigger>
          <AccordionContent>
            The dashboard uses a color-coded system to indicate your performance in each category. Green indicates good
            performance, yellow is average, and red suggests areas for improvement. The exact thresholds may vary by
            category.
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="item-4">
          <AccordionTrigger>How often should I update my information?</AccordionTrigger>
          <AccordionContent>
            For the most accurate tracking, try to update your information weekly or monthly. However, some categories
            like energy consumption might be better updated on a quarterly basis, depending on your billing cycle.
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="item-5">
          <AccordionTrigger>Can I reset my data?</AccordionTrigger>
          <AccordionContent>
            Currently, there's no built-in reset function. If you need to reset your data, you can clear your browser's
            local storage. Please note that this will erase all saved data and cannot be undone.
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="item-6">
          <AccordionTrigger>How can I improve my scores?</AccordionTrigger>
          <AccordionContent>
            Check out the Guidelines page for detailed tips on improving your sustainability in various areas.
            Additionally, participate in the Sustainability Game to learn new habits and earn points.
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="item-7">
          <AccordionTrigger>Is my data private?</AccordionTrigger>
          <AccordionContent>
            Yes, all your data is stored locally in your browser and is not sent to any external servers. However, this
            means your data won't sync across devices.
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="item-8">
          <AccordionTrigger>How accurate are the calculations?</AccordionTrigger>
          <AccordionContent>
            The calculations are based on general estimates and averages. While they provide a good indication of your
            sustainability efforts, they may not be 100% accurate for every individual situation. We're constantly
            working to improve the accuracy of our calculations.
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="item-9">
          <AccordionTrigger>Can I suggest new features or report bugs?</AccordionTrigger>
          <AccordionContent>
            We welcome feedback and suggestions. Please use the contact form on our website or email us directly at
            support@ecotrack.com with your ideas or to report any issues you encounter.
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="item-10">
          <AccordionTrigger>How can I get involved in local sustainability efforts?</AccordionTrigger>
          <AccordionContent>
            There are many ways to get involved locally. Look for environmental groups or initiatives in your area,
            participate in community clean-up events, or start your own sustainability project. You can also check with
            your local government for any green initiatives or volunteer opportunities.
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  )
}

