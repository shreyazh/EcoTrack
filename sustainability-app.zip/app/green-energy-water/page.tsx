"use client"

import { Calculator } from "@/components/calculator"

export default function GreenEnergyWaterPage() {
  const calculateGreenImpact = (values: Record<string, number | string>) => {
    const waterUsage = values.waterUsage as number
    const renewableEnergy = values.renewableEnergy as number

    const waterScore = 100 - waterUsage / 10 // Assuming 100 liters is the baseline
    const energyScore = renewableEnergy

    return (waterScore + energyScore) / 2
  }

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold tracking-tight">Green Energy & Water Conservation Tracker</h1>
      <Calculator
        title="Calculate Your Green Energy & Water Impact"
        description="Estimate your contribution to green energy usage and water conservation."
        fields={[
          { name: "waterUsage", label: "Daily Water Usage (liters)", type: "number" },
          { name: "renewableEnergy", label: "Renewable Energy Usage (%)", type: "number" },
        ]}
        onCalculate={calculateGreenImpact}
        resultUnit="impact score"
        updateKey="waterConserved"
      />
    </div>
  )
}

