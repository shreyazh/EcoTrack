"use client"

import { Calculator } from "@/components/calculator"

export default function SustainableTravelPage() {
  const calculateSustainableTravel = (values: Record<string, number | string>) => {
    const distance = values.distance as number
    const mode = values.mode as string
    const fuelType = values.fuelType as string

    let impact = distance
    if (mode === "car") {
      impact *= fuelType === "electric" ? 0.1 : 0.5
    } else if (mode === "bus") {
      impact *= 0.2
    } else if (mode === "train") {
      impact *= 0.1
    } else if (mode === "bike") {
      impact *= 0
    } else if (mode === "flight") {
      impact *= 1.5
    }

    return impact
  }

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold tracking-tight">Sustainable Travel & Commute Tracker</h1>
      <Calculator
        title="Calculate Your Travel Impact"
        description="Estimate the environmental impact of your travel and commute."
        fields={[
          { name: "distance", label: "Distance (km)", type: "number" },
          {
            name: "mode",
            label: "Mode of Transport",
            type: "select",
            options: ["car", "bus", "train", "flight", "bike"],
          },
          {
            name: "fuelType",
            label: "Fuel Type (for cars)",
            type: "select",
            options: ["petrol", "diesel", "electric", "hybrid"],
          },
        ]}
        onCalculate={calculateSustainableTravel}
        resultUnit="impact points"
        updateKey="sustainableTravel"
      />
    </div>
  )
}

