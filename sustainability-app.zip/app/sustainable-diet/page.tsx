"use client"

import { Calculator } from "@/components/calculator"

export default function SustainableDietPage() {
  const calculateDietImpact = (values: Record<string, number | string>) => {
    const meat = values.meat as number
    const dairy = values.dairy as number
    const grains = values.grains as number
    const vegetables = values.vegetables as number
    const source = values.source as string

    let score = 100 - (meat * 2 + dairy) + (grains + vegetables) / 2
    if (source === "local") {
      score += 10
    }

    return Math.min(Math.max(score, 0), 100) // Ensure score is between 0 and 100
  }

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold tracking-tight">Sustainable Diet Impact Tracker</h1>
      <Calculator
        title="Calculate Your Diet Sustainability"
        description="Estimate the environmental impact of your daily food intake."
        fields={[
          { name: "meat", label: "Meat Intake (kg)", type: "number" },
          { name: "dairy", label: "Dairy Intake (kg)", type: "number" },
          { name: "grains", label: "Grains Intake (kg)", type: "number" },
          { name: "vegetables", label: "Vegetables Intake (kg)", type: "number" },
          { name: "source", label: "Food Source", type: "select", options: ["local", "imported"] },
        ]}
        onCalculate={calculateDietImpact}
        resultUnit="/100"
        updateKey="sustainableDietScore"
      />
    </div>
  )
}

