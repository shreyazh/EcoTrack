"use client"

import { Calculator } from "@/components/calculator"

export default function WaterFootprintPage() {
  const calculateWaterFootprint = (values: Record<string, number | string>) => {
    // Simplified calculation
    const household = (values.shower as number) + (values.laundry as number) + (values.dishwashing as number)
    const diet = (values.meat as number) * 15000 + (values.dairy as number) * 1000 + (values.vegetables as number) * 300
    const products = (values.products as number) * 40

    return household + diet + products
  }

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold tracking-tight">Water Footprint Calculator</h1>
      <Calculator
        title="Calculate Your Water Footprint"
        description="Estimate your water usage based on your daily activities and diet."
        fields={[
          { name: "shower", label: "Shower Usage (liters)", type: "number" },
          { name: "laundry", label: "Laundry Usage (liters)", type: "number" },
          { name: "dishwashing", label: "Dishwashing Usage (liters)", type: "number" },
          { name: "meat", label: "Meat Consumption (kg)", type: "number" },
          { name: "dairy", label: "Dairy Consumption (kg)", type: "number" },
          { name: "vegetables", label: "Vegetable Consumption (kg)", type: "number" },
          { name: "products", label: "Money Spent on Products ($)", type: "number" },
        ]}
        onCalculate={calculateWaterFootprint}
        resultUnit="liters"
      />
    </div>
  )
}

