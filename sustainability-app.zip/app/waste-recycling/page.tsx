"use client"

import { Calculator } from "@/components/calculator"

export default function WasteRecyclingPage() {
  const calculateWasteImpact = (values: Record<string, number | string>) => {
    // Simplified calculation
    const landfill = (values.landfill as number) * 0.5
    const recycling = (values.recycling as number) * 0.1
    const compost = (values.compost as number) * 0.05

    return landfill + recycling + compost
  }

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold tracking-tight">Waste & Recycling Impact Calculator</h1>
      <Calculator
        title="Calculate Your Waste Impact"
        description="Estimate the environmental impact of your waste and recycling habits."
        fields={[
          { name: "landfill", label: "Landfill Waste (kg)", type: "number" },
          { name: "recycling", label: "Recycled Waste (kg)", type: "number" },
          { name: "compost", label: "Composted Waste (kg)", type: "number" },
          {
            name: "disposalMethod",
            label: "Primary Disposal Method",
            type: "select",
            options: ["landfill", "recycling", "compost"],
          },
        ]}
        onCalculate={calculateWasteImpact}
        resultUnit="kg CO2e"
      />
    </div>
  )
}

