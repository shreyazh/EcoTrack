import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function GuidelinesPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold tracking-tight">Sustainability Guidelines</h1>

      <Card className="bg-green-900 border-green-700">
        <CardHeader>
          <CardTitle>Energy Conservation</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 space-y-2">
            <li>Turn off lights and electronics when not in use</li>
            <li>Use energy-efficient LED bulbs</li>
            <li>Optimize your thermostat settings (68°F in winter, 78°F in summer)</li>
            <li>Use natural light and ventilation when possible</li>
            <li>Unplug chargers and appliances when not in use to avoid phantom energy consumption</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-green-900 border-green-700">
        <CardHeader>
          <CardTitle>Water Conservation</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 space-y-2">
            <li>Fix leaky faucets and pipes</li>
            <li>Install low-flow showerheads and faucet aerators</li>
            <li>Collect rainwater for gardening</li>
            <li>Take shorter showers</li>
            <li>Use drought-resistant plants in your landscaping</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-green-900 border-green-700">
        <CardHeader>
          <CardTitle>Waste Reduction</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 space-y-2">
            <li>Reduce, Reuse, Recycle - in that order</li>
            <li>Compost organic waste</li>
            <li>Avoid single-use plastics</li>
            <li>Donate or repurpose items instead of throwing them away</li>
            <li>Buy products with minimal packaging</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-green-900 border-green-700">
        <CardHeader>
          <CardTitle>Sustainable Transportation</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 space-y-2">
            <li>Use public transportation when possible</li>
            <li>Carpool or use ride-sharing services</li>
            <li>Walk or bike for short distances</li>
            <li>Consider an electric or hybrid vehicle for your next car purchase</li>
            <li>Combine errands to reduce overall travel</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-green-900 border-green-700">
        <CardHeader>
          <CardTitle>Eco-Friendly Shopping</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 space-y-2">
            <li>Buy local and seasonal products</li>
            <li>Choose products with eco-friendly certifications</li>
            <li>Bring your own reusable bags</li>
            <li>Support companies with strong sustainability practices</li>
            <li>Consider second-hand or refurbished items</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-green-900 border-green-700">
        <CardHeader>
          <CardTitle>Sustainable Diet</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 space-y-2">
            <li>Reduce meat consumption, especially red meat</li>
            <li>Choose sustainably sourced seafood</li>
            <li>Eat more plant-based meals</li>
            <li>Buy organic when possible</li>
            <li>Minimize food waste by planning meals and properly storing food</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-green-900 border-green-700">
        <CardHeader>
          <CardTitle>Home Energy Efficiency</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 space-y-2">
            <li>Improve insulation in walls, attic, and floors</li>
            <li>Use energy-efficient appliances</li>
            <li>Install solar panels if feasible</li>
            <li>Use smart power strips</li>
            <li>Regularly maintain HVAC systems for optimal efficiency</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="bg-green-900 border-green-700">
        <CardHeader>
          <CardTitle>Community Involvement</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 space-y-2">
            <li>Participate in local environmental initiatives</li>
            <li>Educate others about sustainability</li>
            <li>Support policies that promote environmental protection</li>
            <li>Join or organize community clean-up events</li>
            <li>Share resources and tools with neighbors to reduce individual consumption</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

