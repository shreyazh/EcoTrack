"use client"

import { Calculator } from "@/components/calculator"

export default function CarbonFootprintPage() {
  const calculateCarbonFootprint = (values: Record<string, number | string>) => {
    // This is a simplified calculation. In a real app, you'd use more complex formulas.
    const transport = (values.distance as number) * (values.mode === "car" ? 0.2 : 0.1)
    const energy = (values.energy as number) * (values.source === "coal" ? 0.9 : 0.4)
    const food = (values.food as number) * (values.foodType === "meat" ? 13.3 : 2.9)
    const shopping = (values.shopping as number) * 0.5
    const waste = (values.waste as number) * (values.wasteType === "landfill" ? 0.7 : 0.3)

    return transport + energy + food + shopping + waste
  }

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold tracking-tight">Carbon Footprint Calculator</h1>
      <Calculator
        title="Calculate Your Carbon Footprint"
        description="Estimate your carbon emissions based on your daily activities."
        fields={[
          { name: "distance", label: "Distance Traveled (km)", type: "number" },
          { name: "mode", label: "Mode of Transport", type: "select", options: ["car", "public transport"] },
          { name: "energy", label: "Energy Consumed (kWh)", type: "number" },
          { name: "source", label: "Energy Source", type: "select", options: ["coal", "renewable"] },
          { name: "food", label: "Food Consumed (kg)", type: "number" },
          { name: "foodType", label: "Food Type", type: "select", options: ["meat", "plant-based"] },
          { name: "shopping", label: "Money Spent on Shopping ($)", type: "number" },
          { name: "waste", label: "Waste Generated (kg)", type: "number" },
          { name: "wasteType", label: "Waste Type", type: "select", options: ["landfill", "recycled"] },
        ]}
        onCalculate={calculateCarbonFootprint}
        resultUnit="kg CO2e"
      />
    </div>
  )
}

