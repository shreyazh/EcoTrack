"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { BarChart2, Droplet, Zap, Recycle, Car, ShoppingBag, Sun, Apple, Leaf, Trophy } from "lucide-react"
import { useSustainability } from "@/contexts/SustainabilityContext"

export default function Dashboard() {
  const { data } = useSustainability()

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold tracking-tight">Sustainability Dashboard</h1>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <DashboardCard title="Carbon Footprint" icon={BarChart2} value={data.carbonFootprint} unit="kg CO2e" />
        <DashboardCard title="Water Footprint" icon={Droplet} value={data.waterFootprint} unit="liters" />
        <DashboardCard title="Energy Consumption" icon={Zap} value={data.energyConsumption} unit="kWh" />
        <DashboardCard title="Waste Recycled" icon={Recycle} value={data.wasteRecycled} unit="%" />
        <DashboardCard title="Sustainable Travel" icon={Car} value={data.sustainableTravel} unit="km" />
        <DashboardCard title="Eco-Friendly Purchases" icon={ShoppingBag} value={data.ecoFriendlyPurchases} unit="%" />
        <DashboardCard title="Solar Energy Generated" icon={Sun} value={data.solarEnergyGenerated} unit="kWh" />
        <DashboardCard title="Sustainable Diet Score" icon={Apple} value={data.sustainableDietScore} unit="/100" />
        <DashboardCard title="Water Conserved" icon={Leaf} value={data.waterConserved} unit="liters" />
        <DashboardCard title="Sustainability Score" icon={Trophy} value={data.sustainabilityScore} unit="points" />
      </div>
    </div>
  )
}

function DashboardCard({ title, icon: Icon, value, unit }: { title: string; icon: any; value: number; unit: string }) {
  return (
    <Card className="bg-green-900 border-green-700">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-green-400" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">
          {value.toFixed(2)}
          {unit}
        </div>
        <Progress value={value} className="mt-2" />
      </CardContent>
    </Card>
  )
}

