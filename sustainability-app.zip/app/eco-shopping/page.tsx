"use client"

import { Calculator } from "@/components/calculator"

export default function EcoShoppingPage() {
  const calculateEcoShopping = (values: Record<string, number | string>) => {
    const amount = values.amount as number
    const type = values.type as string
    const rating = values.rating as number

    let impact = amount
    if (type === "clothing") {
      impact *= 0.8
    } else if (type === "electronics") {
      impact *= 1.2
    } else if (type === "groceries") {
      impact *= 0.6
    }

    impact *= (6 - rating) / 5 // Higher rating means lower impact

    return 100 - impact // Return as a percentage of eco-friendliness
  }

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold tracking-tight">Eco-Friendly Shopping Impact Tracker</h1>
      <Calculator
        title="Calculate Your Shopping Impact"
        description="Estimate the environmental impact of your shopping habits."
        fields={[
          { name: "amount", label: "Amount Spent ($)", type: "number" },
          { name: "type", label: "Purchase Type", type: "select", options: ["clothing", "electronics", "groceries"] },
          { name: "rating", label: "Brand Sustainability Rating (1-5)", type: "number" },
        ]}
        onCalculate={calculateEcoShopping}
        resultUnit="% eco-friendly"
        updateKey="ecoFriendlyPurchases"
      />
    </div>
  )
}

