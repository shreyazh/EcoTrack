"use client"

import { Calculator } from "@/components/calculator"

export default function EnergyConsumptionPage() {
  const calculateEnergyConsumption = (values: Record<string, number | string>) => {
    // Simplified calculation
    const electricity = (values.electricity as number) * (values.source === "coal" ? 1 : 0.5)
    const appliances = ((values.usageTime as number) * (values.powerRating as number)) / 1000

    return electricity + appliances
  }

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold tracking-tight">Energy Consumption Tracker</h1>
      <Calculator
        title="Track Your Energy Consumption"
        description="Estimate your energy usage based on your electricity consumption and appliance usage."
        fields={[
          { name: "electricity", label: "Electricity Consumption (kWh)", type: "number" },
          { name: "source", label: "Energy Source", type: "select", options: ["coal", "gas", "solar"] },
          { name: "usageTime", label: "Appliance Usage Time (hours)", type: "number" },
          { name: "powerRating", label: "Appliance Power Rating (watts)", type: "number" },
        ]}
        onCalculate={calculateEnergyConsumption}
        resultUnit="kWh"
      />
    </div>
  )
}

