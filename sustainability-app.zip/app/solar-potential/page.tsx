"use client"

import { Calculator } from "@/components/calculator"

export default function SolarPotentialPage() {
  const calculateSolarPotential = (values: Record<string, number | string>) => {
    const area = values.area as number
    const sunlightHours = values.sunlightHours as number
    const efficiency = values.efficiency as number

    // Simple calculation: area * sunlight hours * efficiency * 1000 W/m^2 * 0.001 kW/W
    return area * sunlightHours * (efficiency / 100) * 1000 * 0.001
  }

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold tracking-tight">Home Solar Potential Estimator</h1>
      <Calculator
        title="Estimate Your Solar Potential"
        description="Calculate the potential solar energy generation for your home."
        fields={[
          { name: "area", label: "Panel Area (m²)", type: "number" },
          { name: "sunlightHours", label: "Average Daily Sunlight Hours", type: "number" },
          { name: "efficiency", label: "Panel Efficiency (%)", type: "number" },
        ]}
        onCalculate={calculateSolarPotential}
        resultUnit="kWh/day"
        updateKey="solarEnergyGenerated"
      />
    </div>
  )
}

