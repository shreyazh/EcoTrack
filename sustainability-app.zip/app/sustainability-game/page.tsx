"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useSustainability } from "@/contexts/SustainabilityContext"

const challenges = [
  { id: 1, title: "Use public transport", points: 10 },
  { id: 2, title: "Eat a vegetarian meal", points: 5 },
  { id: 3, title: "Reduce shower time by 2 minutes", points: 3 },
  { id: 4, title: "Use a reusable water bottle", points: 2 },
  { id: 5, title: "Turn off lights when leaving a room", points: 1 },
]

export default function SustainabilityGamePage() {
  const [completedChallenges, setCompletedChallenges] = useState<number[]>([])
  const { data, updateData } = useSustainability()

  const handleCompleteChallenge = (id: number, points: number) => {
    if (!completedChallenges.includes(id)) {
      setCompletedChallenges([...completedChallenges, id])
      updateData("sustainabilityScore", data.sustainabilityScore + points)
    }
  }

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold tracking-tight">Sustainability Game</h1>
      <p className="text-lg">Complete challenges to earn points and improve your sustainability score!</p>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {challenges.map((challenge) => (
          <Card key={challenge.id} className="bg-green-900 border-green-700">
            <CardHeader>
              <CardTitle>{challenge.title}</CardTitle>
              <CardDescription>Points: {challenge.points}</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Complete this challenge to earn points!</p>
            </CardContent>
            <CardFooter>
              <Button
                onClick={() => handleCompleteChallenge(challenge.id, challenge.points)}
                disabled={completedChallenges.includes(challenge.id)}
              >
                {completedChallenges.includes(challenge.id) ? "Completed" : "Complete Challenge"}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

